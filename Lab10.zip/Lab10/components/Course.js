// Lab 10
import React from 'react'
import {StyleSheet, TouchableOpacity, Text} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

export default function Course({ pressHandler, item }) {
    return (
        <TouchableOpacity onPress={() => pressHandler(item.key)}>
        <Text style={styles.item}>{item.name} <MaterialIcons name='info' size={20} color='#333' /> </Text>
        </TouchableOpacity>
    )
}

const styles = StyleSheet.create({
    item:{
            padding: 10,
            marginTop: 16,
            borderColor: '#bbb',
            borderWidth: 1,
            borderStyle: 'dashed',
            borderRadius: 10,
        },
    })