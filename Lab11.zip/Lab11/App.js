import React, { useState, useEffect } from 'react';
import { View, Text } from 'react-native';
import * as Font from 'expo-font';
import AppLoading from 'expo-app-loading'; // Use this if you're using an older version of Expo
import Home from './Screens/Home';

export default function App() {
  const [fontsLoaded, setFontsLoaded] = useState(false);

  useEffect(() => {
    async function loadFonts() {
      await Font.loadAsync({
        'Oswald': require('./assets/fonts/RubikScribble-Regular.ttf'),
        // Add other font styles here if necessary
      });
      setFontsLoaded(true);
    }

    loadFonts();
  }, []);

  if (!fontsLoaded) {
    return <AppLoading />; // Show a loading screen until the font is loaded
  }

  return (
    <View style={{ flex: 1, backgroundColor: 'black' }}>
      <Home />
    </View>
  );
}
