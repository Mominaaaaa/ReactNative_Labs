import React from 'react';
import Navigator from './Routes/HomeStack';
export default function App() {
return (
<Navigator />
);
}