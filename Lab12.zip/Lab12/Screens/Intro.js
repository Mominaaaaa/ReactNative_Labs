import React from 'react';
import { StyleSheet, View, Text, Button } from 'react-native';
import { GlobalStyles } from '../Styles/GlobalStyles';

export default function Intro({ navigation }) {
const pressHandler = () => {
navigation.goBack();
}
return (
<View style={GlobalStyles.containerGlobal}>
<Text>Hello! My Name is Momina</Text>
<Button title='go back' onPress={pressHandler} />
</View>
);
}