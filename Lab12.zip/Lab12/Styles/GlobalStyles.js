import { StyleSheet } from 'react-native';

export const GlobalStyles = StyleSheet.create({

    containerGlobal: {
        flex: 1,
        justifyContent: 'center',
        backgroundColor: 'orange',
        padding: 8,
    },  
    paragraphGlobal: {     
        marginTop: 18,     
        fontSize: 28,      
        fontWeight: 'bold',     
        textAlign: 'center',   
    }, 
}); 