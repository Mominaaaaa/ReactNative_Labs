import React from 'react';
import Navigation from './Navigation';

const App = () => {
  return <Navigation />;
};
export default App;