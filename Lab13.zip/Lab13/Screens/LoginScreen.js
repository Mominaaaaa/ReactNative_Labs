import React, { useState } from 'react';
import { View, TextInput, Button, Alert } from 'react-native';
import firebase from '../firebase'; // Import the firebase configuration 
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';

const LoginScreen = ({ navigation }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState(''); 

    const handleLogin = () => {
        const auth = getAuth(firebase); // Get the Firebase Auth instance

        signInWithEmailAndPassword(auth, email, password)
        .then(() => {
            // Navigate to Home screen or any other screen
            navigation.navigate('Home'); 
        })
        .catch(error => {
            // Handle login errors
            Alert.alert('Error', error.message);
        });
    }; 
    return (
    <View>
        <TextInput
        placeholder="Email"
        onChangeText={text => setEmail(text)}
        value={email}
        /> 
        <TextInput
        placeholder="Password"
        onChangeText={text => setPassword(text)}
        value={password}
        secureTextEntry
        />
        <Button title="Login" onPress={handleLogin} />
    </View>
    );
};
export default LoginScreen;