import React, { useState } from 'react';
import { View, TextInput, Button, Alert } from 'react-native';
import firebase from '../firebase'; // Import the firebase configuration 
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';


const SignupScreen = ({ navigation }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSignup = () => {
        const auth = getAuth(firebase); // Get the Firebase Auth instance

        createUserWithEmailAndPassword(auth, email, password)
        .then(() => {  // Navigate to Home screen or any other screen
            navigation.navigate('Home');
        })
        .catch(error => {   // Handle signup errors
            Alert.alert('Error', error.message);
        });
    };
    return (
    <View>
        <TextInput
        placeholder="Email"
        onChangeText={text => setEmail(text)}
        value={email}
        />
        <TextInput
        placeholder="Password"
        onChangeText={text => setPassword(text)}
        value={password}
        secureTextEntry
        />
        <Button title="Signup" onPress={handleSignup} />
    </View>
    );
};
export default SignupScreen;