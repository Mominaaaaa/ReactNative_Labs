// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries


// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAGHyBYSTeudO8YGS0R_6ifbff-Nymabow",
  authDomain: "lab13-firebase-1.firebaseapp.com",
  projectId: "lab13-firebase-1",
  storageBucket: "lab13-firebase-1.appspot.com",
  messagingSenderId: "569224705470",
  appId: "1:569224705470:web:4675da51b86893534275ef"
};
console.log("Firebase Config:", firebaseConfig);

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default firebaseConfig; 