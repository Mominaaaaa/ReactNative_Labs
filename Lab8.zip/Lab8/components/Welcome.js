// Lab 8
import * as React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

export default function Welcome() {
return (
<ScrollView indicatorStyle={"white"} style={ styles.container}>
    <Text
    style={styles.headerText}>
    The 346th day of the year (347th in leap years) in the Gregorian
    calendar
    </Text>
    <Text
    style={styles.regularText }>
    19 days remain until the end of the year
    </Text>
</ScrollView>
);
}
const styles = StyleSheet.create({
    container: {
    flex: 1,
    },
    headerText: {
    padding: 40,
    fontSize: 30,
    color: 'green',
    textAlign: 'center',
    },
    regularText: {
    fontSize: 24,
    padding: 20,
    marginVertical: 8,
    color: 'green',
    textAlign: 'center',
},
});